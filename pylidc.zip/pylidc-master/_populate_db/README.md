# Populate the pylidc sqlite database

## *You do do not need to run these scripts*

These script and files are left here so that one can change and extend the `pylidc` module. However, the database has already been populated to use the `pylidc` module as-is, and thus, the populate script does not need to be run otherwise.

The files and folders here are those that are used to populate the `pylidc.db` database used in the above module.

See the `populate.py` script for further detail if you wish to make modifications to the `pylidc` module's models and hence the database.
